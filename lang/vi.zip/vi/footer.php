<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Footer
    |--------------------------------------------------------------------------
    */

    'join' => 'Tham gia',
    'join_us_today' => 'Tham gia cùng chúng tôi ngay hôm nay',
    'subscribe_content' => '#Chúng tôi sẽ gửi những ưu đãi và khuyến mãi tốt nhất đến email của bạn.',
    'enter_email_here' => 'Nhập email của bạn vào đây',

];
