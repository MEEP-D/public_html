<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Admin Results Translation
    |--------------------------------------------------------------------------
    */

    'quiz_result_list_page_title' => 'Kết quả bài kiểm tra',

    'admin_quiz_result' => 'Kết quả bài kiểm tra',
    'admin_quiz_result_list' => 'Danh sách kết quả bài kiểm tra',
    'admin_quiz_result_create' => 'Tạo kết quả bài kiểm tra',
    'admin_quiz_result_edit' => 'Chỉnh sửa kết quả bài kiểm tra',
    'admin_quiz_result_delete' => 'Xóa kết quả bài kiểm tra',
];