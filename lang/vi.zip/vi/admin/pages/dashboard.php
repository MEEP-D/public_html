<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Admin Dashboard Translation
    |--------------------------------------------------------------------------
    */

    'dashboard' => 'Bảng điều khiển',
    'admin_dashboard_show' => 'Hiển thị bảng điều khiển',
];