<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication & Password
    |--------------------------------------------------------------------------
    |
    |
    */

    'reset' => 'Mật khẩu của bạn đã được đặt lại!',
    'sent' => 'Chúng tôi đã gửi email liên kết đặt lại mật khẩu của bạn!',
    'throttled' => 'Vui lòng đợi trước khi thử lại.',
    'token' => 'Liên kết đặt lại mật khẩu này không hợp lệ.',
    'user' => 'Không tìm thấy người dùng với địa chỉ email này.',

];