<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Forms
    |--------------------------------------------------------------------------
    */

    'maximum_64_characters' => 'Tối đa 64 ký tự',
    'maximum_255_characters' => 'Tối đa 255 ký tự',
    'maximum_128_characters' => 'Tối đa 128 ký tự',
    '50_160_characters_preferred' => 'Ưu tiên từ 155 - 160 ký tự',
    'maximum_50_characters' => 'Tối đa 50 ký tự',
    'course_thumbnail_size' => 'Kích thước ưu tiên 360x250px',
    'course_cover_size' => 'Kích thước ưu tiên 1920x530px',
    'max' => 'Tối đa',
    'capacity_placeholder' => 'Bạn sẽ tiếp nhận bao nhiêu học viên?',
    'subscribe_hint' => 'Học viên có thể đăng ký nội dung của bạn bên cạnh việc mua trực tiếp.',
    'webinar_description_placeholder' => 'Tối thiểu 300 từ. Hỗ trợ HTML và hình ảnh.',
    'empty_means_unlimited' => 'Để trống nếu không giới hạn.',

];
