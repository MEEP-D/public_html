<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Navbar
    |--------------------------------------------------------------------------
    */

    'search_anything' => 'Tìm kiếm...',
    'home' => 'Trang chủ',
    'about_us' => 'Giới thiệu về chúng tôi',
    'contact' => 'Liên hệ',
    'blog' => 'Blog',
    'terms' => 'Điều khoản',
    'items' => 'Mục',
    'menu' => 'Menu',
    'title' => 'Tiêu đề',
    'start_a_live_class' => 'Bắt đầu khóa học mới',



];
